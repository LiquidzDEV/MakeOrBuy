MakeOrBuy Tool von (Anteil in der Pr�sentation):

Pascal Hobza (Vorstellung des Programms / Was geschieht im Hintergrund? / Kurze Erkl�rung Java)
Rene Dahl (Entstehung / Idee)
Andreas Sorgenicht (Fragen und Antworten)
Mehdi Can (Einleitung / Schluss)

Das Programm ben�tigt mindestens Java 1.8 oder h�her.
Wenn sie Probleme oder Schwierigkeiten beim ausf�hren haben, habe ich Ihnen im 
Ordner "pictures" ein paar Bilder des Programms hinterlegt.